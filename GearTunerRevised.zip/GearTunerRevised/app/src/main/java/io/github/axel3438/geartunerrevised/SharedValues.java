package io.github.axel3438.geartunerrevised;

import android.content.Context;
import android.os.Build;
import android.support.annotation.RequiresApi;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Paths;
import java.util.Scanner;

/**
 * Created by Alex on 3/12/2018.
 * used to save Values which will be used to stop people from refilling information and a saving bed
 * altered code from https://stackoverflow.com/questions/4878159/whats-the-best-way-to-share-data-between-activities
 * to serve my porpoise.... yes, i have an imaginary turtle.
 */

public class SharedValues {
    private static SharedValues holder = new SharedValues((float) -1);
    private float FWidth = -1;
    private float FRadius = -1;
    private float FDiameter = -1;
    private float RWidth = -1;
    private float RRadius = -1;
    private float RDiameter = -1;
    //start with final gear, the rest are the actual gear values.
    private float[] Gears = new float[13];
    private float[] Speed = new float[12];
    private float Correction = 1;
    private float shift = -1;
    private String DriveType = "not set";
    private double MaxOD = -1;
    private boolean clear = false;


    public SharedValues(Float setVal) {
        for (int i = 0; i < 11; i++) {
            this.Gears[i] = setVal;
            this.Speed[i] = setVal;
        }
        this.Gears[12] = setVal;
    }


    //a block of butchered things here. they assume the size will work for all of these, and has almost no safety in place at all
    public float[] GetGears() {
        return this.Gears;
    }

    public void SetGears(float[] CurrentGears) {
        for (int i = 0; i < CurrentGears.length && i < 13; i++) {
            this.Gears[i] = CurrentGears[i];
        }
    }

    //same issue
    public float[] GetSpeed() {
        return this.Speed;
    }

    public void SetSpeed(float[] CurrentSpeeds) {
        for (int i = 0; i < CurrentSpeeds.length && i < 12; i++) {
            this.Speed[i] = CurrentSpeeds[i];
        }
    }

    public float GetFWidth() {
        return this.FWidth;
    }

    public void SetFWidth(float newVal) {
        this.FWidth = newVal;
    }

    public float GetRWidth() {
        return this.RWidth;
    }

    public void SetRWidth(float newVal) {
        this.RWidth = newVal;
    }

    public float GetFRadius() {
        return this.FRadius;
    }

    public void SetFRadius(float newVal) {
        this.FRadius = newVal;
    }

    public float GetRRadius() {
        return this.RRadius;
    }

    public void SetRRadius(float newVal) {
        this.RRadius = newVal;
    }

    public float GetFDiameter() {
        return this.FDiameter;
    }

    public void SetFDiameter(float newVal) {
        this.FDiameter = newVal;
    }

    public float GetRDiameter() {
        return this.RDiameter;
    }

    public void SetRDiameter(float newVal) {
        this.RDiameter = newVal;
    }

    public float GetCorrection() {
        return this.Correction;
    }

    public void SetCorrection(float newVal) {
        this.Correction = newVal;
    }

    public String GetDrive() {
        return DriveType;
    }

    public void SetDrive(String newVal) {
        DriveType = newVal;
    }

    public float GetShift() {
        return shift;
    }

    public void SetShift(float newVal) {
        shift = newVal;
    }

    public double GetOD() {
        return MaxOD;
    }

    public void SetOD(double newVal) {
        MaxOD = newVal;
    }

    public boolean GetClear(){return clear;}
    public void SetClear(boolean set){clear= set;}

    //create an instance of the class, then send the instance whenever it is called upon.
    //this SHOULD then have the same values for every time it is called.
    public static SharedValues getInstance() {
        return holder;
    }

    //stolen from stack overflow, because darn you to heck filestream! https://stackoverflow.com/questions/12910503/read-file-as-string
    public static String getFileContent(FileInputStream fis) throws IOException
    {
        BufferedReader br = null;
        try {
            br = new BufferedReader( new InputStreamReader(fis));
        }
        catch (Exception e){
            e.printStackTrace();
        }
        {
            StringBuilder sb = new StringBuilder();
            String line;
            while(( line = br.readLine()) != null ) {
                sb.append( line );
                sb.append( '\n' );
            }
            return sb.toString();
        }
    }

    //save all values as a sting, then feed to a outputstream. context required for saving
    public void SaveFile(Context context) {


        File MyCar = new File(context.getFilesDir(),"MyCar.txt");
        try {
            MyCar.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }

        FileOutputStream outputStream;
        String data="";

        //force the loose data into data, including values to make it legible.
        data+="FWidth:" + this.FWidth +"\n";
        data+="FDia:" + this.FDiameter +"\n";
        data+="FRad:" + this.FRadius +"\n";
        data+="RWidth:" + this.RWidth +"\n";
        data+="RDia:" + this.RDiameter +"\n";
        data+="RRad:" + this.RRadius +"\n";
        data+="Corr:" + this.Correction +"\n";
        data+="Shift:" + this.shift +"\n";
        data+= "OD:" + this.MaxOD + "\n";
        data+= "DriveType:"+ this.DriveType +"\n";
        for(int i=0; i<Speed.length; i++){
            data+= "Speed"+i+":"+ this.Speed[i]+"\n";
        }
        for(int i=0; i<Gears.length; i++){
            data+= "Gear"+i+":"+ this.Gears[i]+"\n";
        }

        try{
            outputStream= new FileOutputStream(MyCar, false);
            outputStream.write(data.getBytes());
            outputStream.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    // load said file.. nad use the helper getFile Content because.. don't cross the streams?
    public void LoadFile(Context context){
        File MyCar = new File(context.getFilesDir(),"MyCar.txt");
        FileInputStream inputstream;
        String data="";

        try{
            inputstream= new FileInputStream(MyCar);
            data = this.getFileContent(inputstream);
            inputstream.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }

        //so, split the data at newlines. Then make a substring of the string using the : placed in each line.
        //from there, fill in the information and.. it should work?

        if( data.length()!=0){
            String[] BrokenData= data.split("\n");
            String[] TempSpace;
            for( int i=0; i< BrokenData.length; i++){
                TempSpace= BrokenData[i].split(":");
                BrokenData[i]= TempSpace[TempSpace.length-1];
            }
            //now brokenData should only have the data from when this was made.
            // so.. fill in the variables
            if( BrokenData.length !=0){
                this.FWidth= Float.valueOf(BrokenData[0]);
                this.FDiameter= Float.valueOf(BrokenData[1]);
                this.FRadius= Float.valueOf(BrokenData[2]);
                this.RWidth= Float.valueOf(BrokenData[3]);
                this.RDiameter= Float.valueOf(BrokenData[4]);
                this.RRadius= Float.valueOf(BrokenData[5]);
                this.Correction= Float.valueOf(BrokenData[6]);
                this.shift= Float.valueOf(BrokenData[7]);
                this.MaxOD= Double.valueOf(BrokenData[8]);
                this.DriveType= BrokenData[9];

                //the values start at ten, so just add ten to the broken data
                for( int i=0; i<Speed.length; i++){
                    this.Speed[i]= Float.valueOf(BrokenData[i+10]);
                }

                //assuming math is right, speed has 12 values so the offset should be 22.
                for( int i=0; i<Gears.length; i++){
                    this.Gears[i]= Float.valueOf(BrokenData[i+22]);
                }

            }
        }

    }






}
