package io.github.axel3438.geartunerrevised;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class GetRatios extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_ratios);

        //fill the values previously entered!
        EditText textSet;
        for( int i =0; i< SpeedID.length; i++){
            textSet= findViewById(SpeedID[i]);
            if(Speed[i]>0) {
                textSet.setText(String.valueOf(Speed[i]));
            }
        }
        textSet= findViewById(R.id.Gear0);
        if( Gear[0]>0){
            textSet.setText(String.valueOf(Gear[0]));
        }

        textSet= findViewById((R.id.ShiftPoint));
        if(Shift>0){
            textSet.setText(String.valueOf(Shift));
        }

        textSet= findViewById((R.id.Correction));
        if(correction != 1.0){
            textSet.setText(String.valueOf(correction));
        }


    }

    SharedValues localVals= SharedValues.getInstance();
    float[] Speed = localVals.GetSpeed();
    float Shift= localVals.GetShift();
    float[] Gear= localVals.GetGears();
    float correction= localVals.GetCorrection();
    int[] SpeedID= new int[]{R.id.Speed1,R.id.Speed2, R.id.Speed3,R.id.Speed4,R.id.Speed5, R.id.Speed6,
            R.id.Speed7,R.id.Speed8, R.id.Speed9,R.id.Speed10,R.id.Speed11, R.id.Speed12} ;

    public void GetVals(){
        EditText textGrab;
        for(int i=0; i<Speed.length; i++){
            textGrab= findViewById(SpeedID[i]);
            if(textGrab.getText().length() !=0) {
                Speed[i]= Float.valueOf(textGrab.getText().toString());
            }
        }
        localVals.SetSpeed(Speed);

        textGrab= findViewById(R.id.Gear0);
        if(textGrab.getText().length() !=0) {
            Gear[0]= Float.valueOf(textGrab.getText().toString());
        }
        localVals.SetGears(Gear);

        textGrab= findViewById(R.id.ShiftPoint);
        if(textGrab.getText().length() !=0) {
            Shift= Float.valueOf(textGrab.getText().toString());
        }
        localVals.SetShift(Shift);

        textGrab= findViewById(R.id.Correction);
        if(textGrab.getText().length() !=0) {
            correction= Float.valueOf(textGrab.getText().toString());
        }
        localVals.SetCorrection(correction);
    }

    public void RatioMaths(View view){
        Intent intent = new Intent(this, DisplayRatio.class);
        this.GetVals();
        startActivity(intent);
    }
    public void LoadVals(View view){
        localVals.LoadFile(getApplicationContext());
        Intent intent = new Intent(this, GetRatios.class);
        startActivity(intent);
    }
    public void SaveVals(View view){
        this.GetVals();
        localVals.SaveFile(getApplicationContext());
    }
    public void ClearVals(View view){
        Intent intent = new Intent(this, GetRatios.class);
        localVals.SetClear(false);
        startActivity(intent);
    }

}
