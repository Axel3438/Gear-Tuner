package io.github.axel3438.geartunerrevised;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class RedlineRatio extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_redline_ratio);
        EditText textSet;
        for( int i =0; i< GearID.length; i++){
            textSet= findViewById(GearID[i]);
            if(Gear[i]>0) {
                textSet.setText(String.valueOf(Gear[i]));
            }
        }
        textSet= findViewById(R.id.Gear0);
        if( Gear[0]>0){
            textSet.setText(String.valueOf(Gear[0]));
        }

        textSet= findViewById((R.id.Correction));
        if(correction != 1.0){
            textSet.setText(String.valueOf(correction));
        }
    }

    SharedValues localVals= SharedValues.getInstance();
    float[] Gear= localVals.GetGears();
    float correction= localVals.GetCorrection();
    int[] GearID= new int[]{R.id.Gear0,R.id.Gear1,R.id.Gear2, R.id.Gear3,R.id.Gear4,R.id.Gear5, R.id.Gear6,
            R.id.Gear7,R.id.Gear8, R.id.Gear9,R.id.Gear10,R.id.Gear11, R.id.Gear12} ;
    double  MaxOD= localVals.GetOD();
    float[] Speed= localVals.GetSpeed();
    float Correct= localVals.GetCorrection();

    public void GetVals(){
        EditText textGrab;
        for(int i=0; i<GearID.length; i++){
            textGrab= findViewById(GearID[i]);
            if(textGrab.getText().length() !=0) {
                Gear[i]= Float.valueOf(textGrab.getText().toString());
            }
        }
        localVals.SetGears(Gear);

        textGrab= findViewById(R.id.Correction);
        if(textGrab.getText().length() !=0) {
            correction= Float.valueOf(textGrab.getText().toString());
        }
        localVals.SetCorrection(correction);
    }


    public void GetRedline(View view) {
        this.GetVals();
        float Shift=0;
        int gear=0;
        for( int i=1; i<Gear.length; i++) {
            if (Gear[i] > 0) {
                Shift += (float) (((this.Speed[i] * 336.13d * this.Gear[i]* Gear[0]) / (this.MaxOD)) * Correct);
                gear++;
            }
        }
        Shift= Shift/gear;
        localVals.SetShift(Shift);
        Intent intent = new Intent(this, MenuAndTires.class);
        startActivity(intent);
    }
    public void LoadVals(View view){
        localVals.LoadFile(getApplicationContext());
        Intent intent = new Intent(this, RedlineRatio.class);
        startActivity(intent);
    }
    public void SaveVals(View view){
        this.GetVals();
        localVals.SaveFile(getApplicationContext());
    }
    public void ClearVals(View view){
        Intent intent = new Intent(this, RedlineRatio.class);
        localVals.SetClear(false);
        startActivity(intent);
    }
}
