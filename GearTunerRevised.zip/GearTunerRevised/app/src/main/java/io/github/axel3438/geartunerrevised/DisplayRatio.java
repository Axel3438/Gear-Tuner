package io.github.axel3438.geartunerrevised;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class DisplayRatio extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_ratio);
        TextView Mytext;
        Mytext= findViewById(R.id.DisplayRatios);
        Mytext.setText(MakeText());

    }

    SharedValues localvals= SharedValues.getInstance();
    float[] Speed= localvals.GetSpeed();
    float[] Gear= localvals.GetGears();
    float Shift= localvals.GetShift();
    double MaxOD= localvals.GetOD();
    float Correct= localvals.GetCorrection();

    public String MakeText(){
        String val= "";

        for( int i=0; i< 12; i++){
            if( Speed[i]>0) {
                val += "\n";
                val += String.valueOf(i + 1);
                val += " gear ratio is:";
                val += String.valueOf(((this.MaxOD * this.Shift) / (this.Speed[i] * 336.13d * this.Gear[0])) * Correct);
                Gear[i+1]=(float)(((this.MaxOD * this.Shift) / (this.Speed[i] * 336.13d * this.Gear[0]))* Correct);
            }
        }

        localvals.SetGears(Gear);
        return val;
    }

    public void Corrections(View view){
        Intent intent = new Intent(this, CorrectVals.class);
        startActivity(intent);
    }

}
