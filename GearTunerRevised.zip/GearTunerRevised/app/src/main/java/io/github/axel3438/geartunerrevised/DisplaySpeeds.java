package io.github.axel3438.geartunerrevised;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class DisplaySpeeds extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_speeds);
        TextView Mytext;
        Mytext= findViewById(R.id.DisplaySpeed);
        Mytext.setText(MakeText());
    }
    SharedValues localvals= SharedValues.getInstance();
    float[] Speed= localvals.GetSpeed();
    float[] Gear= localvals.GetGears();
    float Shift= localvals.GetShift();
    double MaxOD= localvals.GetOD();
    float Correct= localvals.GetCorrection();

    public String MakeText(){
        String val= "";

        for( int i=1; i< 13; i++){
            if( Gear[i]>0) {
                val += "\n";
                val += String.valueOf(i);
                val += " gear speed is:";
                val += String.valueOf(((this.MaxOD * this.Shift) / (this.Gear[i] * 336.13d * this.Gear[0]))* Correct);
                Speed[i-1]=(float)(((this.MaxOD * this.Shift) / (this.Gear[i] * 336.13d * this.Gear[0]))*Correct);
            }
        }
        return val;
    }

    public void Corrections(View view){
        Intent intent = new Intent(this, CorrectVals.class);
        startActivity(intent);
    }


}
