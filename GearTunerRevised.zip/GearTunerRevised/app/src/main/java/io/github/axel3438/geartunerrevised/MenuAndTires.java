package io.github.axel3438.geartunerrevised;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;

public class MenuAndTires extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_and_tires);

        /*
        In the onCreate, fill in the information if the user is returning to this page from another
        within the app. This is Check the to see if there are others already used, and loading them in
        the place of the text. Check all the tire bits and update the text to the value in sharedValues.
         */

        if (clear){
            EditText SetText= findViewById(R.id.f_dia);
            if(LocalVals.GetFDiameter() != -1.0) {
                SetText.setText(String.valueOf(LocalVals.GetFDiameter()));
            }
            SetText= findViewById(R.id.f_width);
            if(LocalVals.GetFWidth() != -1.0) {
                SetText.setText(String.valueOf(LocalVals.GetFWidth()));
            }
            SetText= findViewById(R.id.f_radius);
            if(LocalVals.GetFRadius() != -1.0) {
                SetText.setText(String.valueOf(LocalVals.GetFRadius()));
            }
            SetText= findViewById(R.id.r_dia);
            if(LocalVals.GetRDiameter() != -1.0) {
                SetText.setText(String.valueOf(LocalVals.GetRDiameter()));
            }
            SetText= findViewById(R.id.r_width);
            if(LocalVals.GetRWidth() != -1.0) {
                SetText.setText(String.valueOf(LocalVals.GetRWidth()));
            }
            SetText= findViewById(R.id.r_radius);
            if(LocalVals.GetRRadius() != -1.0) {
                SetText.setText(String.valueOf(LocalVals.GetRRadius()));
            }
        }
        else{
            LocalVals.SetClear(true);
        }
    }

    //temp local values, can be removed
    public SharedValues LocalVals=  SharedValues.getInstance();
    public float F_width;
    public float F_radius;
    public float F_diameter;
    public float R_width;
    public float R_radius;
    public float R_diameter;
    public String WheelType= LocalVals.GetDrive();
    public double MaxOD= -1;
    boolean clear= LocalVals.GetClear();


    public void GetVals(){
        EditText textGrab = findViewById(R.id.f_dia);
        if(textGrab.getText().length() !=0) {
            F_diameter = Float.valueOf(textGrab.getText().toString());
            LocalVals.SetFDiameter(F_diameter);
        }
        textGrab = findViewById(R.id.f_width);
        if(textGrab.getText().length() !=0) {
            F_width = Float.valueOf(textGrab.getText().toString());
            LocalVals.SetFWidth(F_width);
        }
        textGrab = findViewById(R.id.f_radius);
        if(textGrab.getText().length() !=0) {
            F_radius = Float.valueOf(textGrab.getText().toString());
            LocalVals.SetFRadius(F_radius);
        }
        textGrab = findViewById(R.id.r_dia);
        if(textGrab.getText().length() !=0) {
            R_diameter = Float.valueOf(textGrab.getText().toString());
            LocalVals.SetRDiameter(R_diameter);
        }
        textGrab = findViewById(R.id.r_width);
        if(textGrab.getText().length() !=0) {
            R_width = Float.valueOf(textGrab.getText().toString());
            LocalVals.SetRWidth(R_width);
        }
        textGrab = findViewById(R.id.r_radius);
        if(textGrab.getText().length() !=0) {
            R_radius = Float.valueOf(textGrab.getText().toString());
            LocalVals.SetRRadius(R_radius);
        }
    }


    public void SetWheelType(View view){
        boolean checked = ((RadioButton) view).isChecked();
        // Check which radio button was clicked and set Wheeltype, then update local
        switch(view.getId()) {
            case R.id.AAWD:
                if(checked) {
                    WheelType = "AAWD";
                }
                break;
            case R.id.AWD:
                if(checked) {
                    WheelType = "AWD";
                }
                break;
            case R.id.FWD:
                if(checked) {
                    WheelType = "FWD";
                }
                break;
            case R.id.RWD:
                if(checked) {
                    WheelType = "RWD";
                }
                break;
        }
        LocalVals.SetDrive(WheelType);
    }

    public void FindOD(){
        GetVals();
        // get the vals, and find the OD through what setting and and what sizes
        if (WheelType.equals("FWD")){
            this.MaxOD =(((( this.F_width) * (( this.F_radius) / 100.0d)) * 2.0d) / 25.4d) + ((double) this.F_diameter);
        }
        if (WheelType.equals("RWD")){
            this.MaxOD =(((( this.R_width) * (( this.R_radius) / 100.0d)) * 2.0d) / 25.4d) + ((double) this.R_diameter);
        }
        if (WheelType.equals("AWD")){
            this.MaxOD = (((((( this.R_width) * (( this.R_radius) / 100.0d)) * 2.0d) / 25.4d) + ( this.R_diameter))
                    + ((((( this.F_width) * (( this.F_radius) / 100.0d)) * 2.0d) / 25.4d) + ( this.F_diameter))) / 2.0d;
        }
        if (WheelType.equals("AAWD")){
            this.MaxOD = ((((( (this.R_width + this.F_width)) / 2.0d) * ((((double) (this.R_radius + this.F_radius)) / 2.0d) / 100.0d)) * 2.0d) / 25.4d)
                    + (((double) (this.R_diameter + this.F_diameter)) / 2.0d);
        }

        LocalVals.SetOD(MaxOD);
    }

    public void FindRedline(View view){
        Intent intent = new Intent(this, GetRedline.class);
        this.GetVals();
        FindOD();
       startActivity(intent);
    }

    public void FindRatio(View view){
        Intent intent = new Intent(this, GetRatios.class);
        this.GetVals();
        FindOD();
        startActivity(intent);
    }

    public void FindSpeed(View view){
        Intent intent = new Intent(this, GetSpeed.class);
        this.GetVals();
        FindOD();
        startActivity(intent);
    }

    public void FindFinal(View view){
        Intent intent = new Intent(this, GetFinal.class);
        this.GetVals();
        FindOD();
        startActivity(intent);
    }

    public void LoadVals(View view){
        LocalVals.LoadFile(getApplicationContext());
        Intent intent = new Intent(this, MenuAndTires.class);
        startActivity(intent);
    }
    public void SaveVals(View view){
        this.GetVals();
        LocalVals.SaveFile(getApplicationContext());
    }
    public void ClearVals(View view){
        Intent intent = new Intent(this, MenuAndTires.class);
        LocalVals.SetClear(false);
        startActivity(intent);
    }


}
