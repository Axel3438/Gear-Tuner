package io.github.axel3438.geartunerrevised;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class CorrectVals extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_correct_vals);


        EditText TextSet;
        float[] MathSpeed=localvals.GetSpeed();
        for( int i=0; i<ExpectedSpeed.length; i++){
            if(MathSpeed[i]>0){
                TextSet= findViewById(ExpectedSpeed[i]);
                TextSet.setText(String.valueOf(MathSpeed[i]));
            }
        }
    }

    SharedValues localvals= SharedValues.getInstance();
    int[] ExpectedSpeed= new  int[]{R.id.Expect1, R.id.Expect2, R.id.Expect3, R.id.Expect4,
                                    R.id.Expect5, R.id.Expect6, R.id.Expect7, R.id.Expect8,
                                    R.id.Expect9};
    int[] ActualSpeed= new  int[]{R.id.Actual1, R.id.Actual2, R.id.Actual3, R.id.Actual4,
                                    R.id.Actual5, R.id.Actual6, R.id.Actual7, R.id.Actual8,
                                    R.id.Actual9};

    float[] ExpectVal= localvals.GetSpeed();
    float[] ActualVals= new float[9];


    public void MakeCorrection(){
        EditText GetText;
        int GearCount=0;
        float TempVal=0;
        for (int i=0; i< this.ActualSpeed.length; i++){
            GetText= findViewById(ActualSpeed[i]);
            if(GetText.getText().length()>0){
                ActualVals[i]= Float.valueOf(GetText.getText().toString());
                GearCount++;
            }
            GetText= findViewById(this.ExpectedSpeed[i]);
            if( GetText.getText().length()>0){
                if(ExpectVal[i] != Float.valueOf(GetText.getText().toString())){
                    ExpectVal[i] =Float.valueOf(GetText.getText().toString());
                }
            }
        }

        for( int i=0; i< GearCount; i++){
            TempVal+= ActualVals[i]/ExpectVal[i];
        }
        TempVal= TempVal/GearCount;
        localvals.SetCorrection(TempVal);
    }

    public void MakeItSo(View view){
        this.MakeCorrection();
        Intent intent = new Intent(this, MenuAndTires.class);
        startActivity(intent);
    }

}
